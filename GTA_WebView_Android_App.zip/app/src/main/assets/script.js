let cash = 5000;
let playerName = "Unknown";

function setPlayerName() {
  const input = document.getElementById("nameInput");
  playerName = input.value || "Player";
  document.getElementById("playerName").innerText = playerName;
  input.value = "";
}

document.getElementById("cash").innerText = cash;
